package com.geegino.signalapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.workDataOf
import com.geegino.signalapp.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.tvIntro.text = "Gee Gino Signals - Core Demo"
        binding.btnRun.setOnClickListener {
            // Example: enqueue a worker to check BTCUSDT 1h
            val data = workDataOf("symbol" to "BTCUSDT", "tf" to "1h")
            val work = OneTimeWorkRequestBuilder<SignalEngineWorker>()
                .setInputData(data)
                .build()
            WorkManager.getInstance(this).enqueue(work)
            binding.tvStatus.text = "Signal check enqueued (BTCUSDT 1h)."
        }
    }
}
