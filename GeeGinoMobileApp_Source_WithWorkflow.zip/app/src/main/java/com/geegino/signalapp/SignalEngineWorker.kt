package com.geegino.signalapp

import android.content.Context
import androidx.work.Worker
import androidx.work.WorkerParameters
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import kotlin.math.abs

class SignalEngineWorker(context: Context, params: WorkerParameters): Worker(context, params) {
    private val http = OkHttpClient()

    override fun doWork(): Result {
        try {
            val symbol = inputData.getString("symbol") ?: "BTCUSDT"
            val timeframe = inputData.getString("tf") ?: "1h"
            val limit = 200
            // For demo, we use Binance klines for BTCUSDT (interval 1h). Map timeframe as needed.
            val url = "https://api.binance.com/api/v3/klines?symbol=${symbol}&interval=1h&limit=$limit"
            val req = Request.Builder().url(url).get().build()
            http.newCall(req).execute().use { resp ->
                if (!resp.isSuccessful) return Result.retry()
                val body = resp.body?.string() ?: return Result.retry()
                val arr = JSONArray(body)
                val closes = mutableListOf<Double>()
                val opens = mutableListOf<Double>()
                val highs = mutableListOf<Double>()
                val lows = mutableListOf<Double>()
                for (i in 0 until arr.length()) {
                    val candle = arr.getJSONArray(i)
                    opens.add(candle.getString(1).toDouble())
                    highs.add(candle.getString(2).toDouble())
                    lows.add(candle.getString(3).toDouble())
                    closes.add(candle.getString(4).toDouble())
                }

                val ema200 = ema(closes, 200)
                val ema50 = ema(closes, 50)
                val rsi14 = rsi(closes, 14)

                val lastClose = closes.last()
                val lastEMA200 = ema200.last()
                val lastEMA50 = ema50.last()
                val lastRSI = rsi14.last()
                val lastOpen = opens.last()
                val isBullish = lastClose > lastOpen
                val isBearish = lastClose < lastOpen

                val buyCond = (lastClose > lastEMA200) && (lastClose <= lastEMA50) && (lastRSI >= 50.0) && isBullish
                val sellCond = (lastClose < lastEMA200) && (lastClose >= lastEMA50) && (lastRSI <= 50.0) && isBearish

                if (buyCond) {
                    val msg = "📈 Gee Gino Alert: BUY $symbol @ ${'$'}{"%.2f".format(lastClose)} ($timeframe)"
                    NotificationHelper.showNotification(applicationContext, "Gee Gino Alert", msg)
                } else if (sellCond) {
                    val msg = "📉 Gee Gino Alert: SELL $symbol @ ${'$'}{"%.2f".format(lastClose)} ($timeframe)"
                    NotificationHelper.showNotification(applicationContext, "Gee Gino Alert", msg)
                }
            }
            return Result.success()
        } catch (e: Exception) {
            e.printStackTrace()
            return Result.failure()
        }
    }

    private fun ema(values: List<Double>, period: Int): List<Double> {
        if (values.isEmpty()) return emptyList()
        val k = 2.0 / (period + 1)
        val out = MutableList(values.size) { 0.0 }
        out[0] = values[0]
        for (i in 1 until values.size) {
            out[i] = values[i] * k + out[i - 1] * (1 - k)
        }
        return out
    }

    private fun rsi(values: List<Double>, period: Int): List<Double> {
        val outs = MutableList(values.size) { 50.0 }
        val deltas = mutableListOf<Double>()
        for (i in 1 until values.size) deltas.add(values[i] - values[i - 1])
        var gain = 0.0
        var loss = 0.0
        for (i in 0 until period) {
            val d = deltas.getOrNull(i) ?: 0.0
            if (d > 0) gain += d else loss -= d
        }
        gain /= period
        loss /= period
        var rs = if (loss == 0.0) 0.0 else gain / loss
        if (period < outs.size) outs[period] = 100.0 - (100.0 / (1 + rs))
        for (i in (period + 1) until values.size) {
            val d = deltas.getOrNull(i - 1) ?: 0.0
            val g = if (d > 0) d else 0.0
            val l = if (d < 0) -d else 0.0
            gain = (gain * (period - 1) + g) / period
            loss = (loss * (period - 1) + l) / period
            rs = if (loss == 0.0) 0.0 else gain / loss
            outs[i] = 100.0 - (100.0 / (1 + rs))
        }
        return outs
    }
}
