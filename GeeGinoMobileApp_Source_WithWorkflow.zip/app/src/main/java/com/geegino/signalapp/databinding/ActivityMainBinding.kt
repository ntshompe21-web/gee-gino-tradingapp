// Simple placeholder binding class to avoid extra Gradle setup in this skeleton.
package com.geegino.signalapp.databinding
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import com.geegino.signalapp.R

class ActivityMainBinding(val root: View, val tvIntro: TextView, val btnRun: Button, val tvStatus: TextView) {
    companion object {
        fun inflate(inflater: LayoutInflater): ActivityMainBinding {
            val view = inflater.inflate(R.layout.activity_main, null)
            val tvIntro = view.findViewById<TextView>(R.id.tvIntro)
            val btnRun = view.findViewById<Button>(R.id.btnRun)
            val tvStatus = view.findViewById<TextView>(R.id.tvStatus)
            return ActivityMainBinding(view, tvIntro, btnRun, tvStatus)
        }
    }
}
