Gee Gino Mobile Signal App - Source Project
-------------------------------------------
This is a minimal Android (Kotlin) project skeleton that implements the core
signal engine (EMA 200, EMA 50, RSI14, simple candlestick check) and sends
personalized notifications in the format:

📈 Gee Gino Alert: BUY SYMBOL @ PRICE (TF)

IMPORTANT:
- This is source code only. You need Android Studio (or a cloud build service)
  to compile this into an APK.
- The project uses placeholder price data via Binance REST for BTC. You should
  configure additional data providers (for Gold, NASDAQ, Dow) and API keys as needed.

Build instructions:
1. Open Android Studio -> Open an existing project -> select this folder.
2. Let Android Studio sync Gradle. If it asks to upgrade Gradle plugin, accept recommended.
3. Click Run -> Build APK. If asked for missing SDKs, install them via SDK Manager.
4. The built APK will be in app/build/outputs/apk/debug/

Quick notes for a dev or builder:
- SignalEngineWorker.kt contains the core logic using Binance klines as an example.
- NotificationHelper.kt shows how to display a local notification.
- Update the network/provider code to add price sources for XAU/USD, indices etc.

Contact:
Gee Gino
Contact: 0627585953
Instagram: @gee.gino
Slogan: Where Strategy Meets Opportunity
